// Example Hardhat deployment script for XQP
const { ethers } = require("hardhat");

async function main() {
  // Replace with your charity wallet address before deploying to mainnet
  const CHARITY_WALLET = process.env.CHARITY_WALLET || "0x0000000000000000000000000000000000000000";
  const Token = await ethers.getContractFactory("XQP");
  const token = await Token.deploy(CHARITY_WALLET);
  await token.deployed();
  console.log("XQP deployed to:", token.address);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});