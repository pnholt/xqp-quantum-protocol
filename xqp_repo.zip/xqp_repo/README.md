# X Quantum Protocol (XQP)

X Quantum Protocol (XQP), sometimes referred to as the **God Coin**, is a
community‑centric ERC‑20 token designed to unite wealth creation with
charitable impact. Each transfer incurs a small tax that is
automatically split between a designated charity wallet and the project
treasury to fund ongoing development and liquidity. Half of the
collected tax goes to faith‑based and humanitarian causes, while the
other half sustains the protocol.

## Key Features

- **Fixed Supply** – A total of **10 billion XQP** tokens are minted at
  deployment. There is no inflation by default, although the owner can
  mint new tokens for controlled distributions (e.g. grants or
  community airdrops).
- **Transfer Tax** – A **2% tax** is applied to every transfer of
  XQP. The tax is split **50/50** between a charity wallet and the
  project treasury (owned by the deployer). This mechanism funds
  real‑world charitable initiatives while ensuring long‑term protocol
  sustainability.
- **Open Source** – Built with
  [OpenZeppelin](https://github.com/OpenZeppelin/openzeppelin-contracts)
  contracts, XQP uses widely‑trusted standards for safety and
  upgradeability.
- **EVM Compatible** – Deployed on EVM networks such as Polygon or Base,
  making it accessible to users through MetaMask and decentralised
  exchanges like QuickSwap.

## Repository Structure

```
├── contracts
│   └── XQP.sol        # Main token contract implementing the transfer tax
├── scripts
│   └── deploy.js      # Example Hardhat deployment script
├── hardhat.config.js  # Hardhat configuration
├── LICENSE            # MIT license
└── README.md          # Project overview and usage instructions
```

## Getting Started

This repository uses [Hardhat](https://hardhat.org/) to compile and
deploy the contract. To experiment locally:

1. Install dependencies:

   ```bash
   npm install --save-dev hardhat @nomicfoundation/hardhat-ethers ethers @openzeppelin/contracts
   ```

2. Configure your networks in `hardhat.config.js` by providing an RPC
   URL and your private key via environment variables.

3. Deploy the contract:

   ```bash
   npx hardhat run scripts/deploy.js --network polygon
   ```

   Replace `polygon` with the desired network (e.g. `polygon`,
   `polygonMumbai`, `base`, etc.). The deployment script accepts a
   placeholder charity wallet address. Be sure to update it before
   deploying to mainnet.

4. Verify the contract on Etherscan/Polygonscan and publish your
   project details.

## Contributing

All contributions are welcome. If you identify issues or have
suggestions for improvements, please open an issue or submit a pull
request. For major changes, discuss your ideas in an issue first.

## License

This project is licensed under the MIT License; see the `LICENSE` file
for details.