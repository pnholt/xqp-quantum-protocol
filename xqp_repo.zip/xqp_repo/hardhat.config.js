require("@nomicfoundation/hardhat-ethers");

// Load environment variables from .env file if present
require("dotenv").config();

/**
 * @type import('hardhat/config').HardhatUserConfig
 */
module.exports = {
  solidity: "0.8.20",
  networks: {
    // Configure your networks here. For example:
    polygon: {
      url: process.env.POLYGON_RPC_URL || "https://polygon-rpc.com",
      accounts: process.env.PRIVATE_KEY ? [process.env.PRIVATE_KEY] : [],
    },
    // Add other networks (e.g. polygonMumbai, base) as needed.
  },
};